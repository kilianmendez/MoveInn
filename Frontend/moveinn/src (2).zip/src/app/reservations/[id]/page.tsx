"use client"

import { Reservation } from "@/components/reservations/reservation"

export default function ReservationPage() {
  return <Reservation />
}

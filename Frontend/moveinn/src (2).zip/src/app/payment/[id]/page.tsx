"use client"
import { PaymentForm } from "@/components/payment/payment-form"

export default function PaymentPage() {
  return <PaymentForm />
}
